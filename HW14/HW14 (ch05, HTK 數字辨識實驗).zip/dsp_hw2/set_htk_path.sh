PATH=$PATH:"/tmp/htk"
